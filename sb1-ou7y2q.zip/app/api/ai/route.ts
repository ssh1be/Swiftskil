import { NextResponse } from 'next/server';
import { searchTopic, generateLessonPlan, generateLessonContent } from '@/lib/ai-service';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  console.log('API route called');
  try {
    const body = await request.json();
    console.log('Request body:', body);

    const { action, payload } = body;

    let result;
    switch (action) {
      case 'searchTopic':
        console.log('Searching topic:', payload.topic);
        result = await searchTopic(payload.topic);
        console.log('Search result:', result);
        break;
      case 'generateLessonPlan':
        console.log('Generating lesson plan:', payload);
        result = await generateLessonPlan(payload);
        console.log('Lesson plan result:', result);
        break;
      case 'generateLessonContent':
        console.log('Generating lesson content:', payload);
        result = await generateLessonContent(payload);
        console.log('Lesson content result:', result);
        break;
      default:
        console.log('Invalid action:', action);
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }

    console.log('Returning result:', result);
    return NextResponse.json(result);
  } catch (error) {
    console.error('API Route Error:', error);
    
    return NextResponse.json({
      error: 'Internal Server Error',
      message: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    }, { status: 500 });
  }
}