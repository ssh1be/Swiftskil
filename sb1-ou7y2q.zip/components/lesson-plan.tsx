"use client"

import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';

export default function LessonPlan({ plan }) {
  const [expandedLesson, setExpandedLesson] = useState(null);
  const [lessonContent, setLessonContent] = useState({});

  const handleExpandLesson = async (lessonId) => {
    if (expandedLesson === lessonId) {
      setExpandedLesson(null);
      return;
    }

    setExpandedLesson(lessonId);

    if (!lessonContent[lessonId]) {
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'generateLessonContent',
          payload: plan.lessons[lessonId]
        }),
      });
      const content = await response.json();
      setLessonContent((prev) => ({ ...prev, [lessonId]: content }));
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{plan.title}</CardTitle>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible>
          {plan.lessons.map((lesson, index) => (
            <AccordionItem key={index} value={`lesson-${index}`}>
              <AccordionTrigger>{lesson.title}</AccordionTrigger>
              <AccordionContent>
                <p>{lesson.description}</p>
                <Button
                  onClick={() => handleExpandLesson(index)}
                  className="mt-2"
                >
                  {expandedLesson === index ? 'Hide Content' : 'Show Content'}
                </Button>
                {expandedLesson === index && lessonContent[index] && (
                  <div className="mt-4">
                    <h4 className="font-semibold mb-2">Lesson Content:</h4>
                    <p>{lessonContent[index].content}</p>
                    <h4 className="font-semibold mt-4 mb-2">Quiz:</h4>
                    <ul className="list-disc pl-5">
                      {lessonContent[index].quiz.map((question, qIndex) => (
                        <li key={qIndex}>{question}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
}