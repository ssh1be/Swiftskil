import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function searchTopic(topic: string) {
  try {
    console.log('Searching topic:', topic);
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OpenAI API key is not set');
    }

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are an AI tutor tasked with providing a brief summary of a given topic."
        },
        {
          role: "user",
          content: `Provide a brief summary of the topic: ${topic}`
        }
      ],
      max_tokens: 150
    });

    console.log('OpenAI response:', JSON.stringify(response, null, 2));

    if (!response.choices || response.choices.length === 0) {
      throw new Error('No response from OpenAI API');
    }

    return {
      topic,
      summary: response.choices[0].message.content,
    };
  } catch (error) {
    console.error('Detailed error in searchTopic:', error);
    throw error; // Propagate the error to be handled in the route handler
  }
}

export async function generateLessonPlan(payload: { topic: string; summary: string }) {
  try {
    console.log('Generating lesson plan for:', payload.topic);
    // Implement the lesson plan generation logic here
    // For now, we'll return a mock lesson plan
    const lessonPlan = {
      title: `Lesson Plan for ${payload.topic}`,
      lessons: [
        { title: 'Introduction', description: 'Overview of the topic' },
        { title: 'Main Concepts', description: 'Key ideas and principles' },
        { title: 'Practical Applications', description: 'Real-world examples and uses' },
        { title: 'Summary', description: 'Recap of main points' },
      ]
    };
    console.log('Generated lesson plan:', lessonPlan);
    return lessonPlan;
  } catch (error) {
    console.error('Error in generateLessonPlan:', error);
    throw error;
  }
}

export async function generateLessonContent(lesson: { title: string; description: string }) {
  try {
    console.log('Generating lesson content for:', lesson.title);
    // Implement the lesson content generation logic here
    // For now, we'll return mock content
    const content = {
      content: `This is the content for the lesson: ${lesson.title}. ${lesson.description}`,
      quiz: [
        'What is the main idea of this lesson?',
        'How can you apply this knowledge in real-life situations?',
        'Explain one key concept from this lesson.',
      ]
    };
    console.log('Generated lesson content:', content);
    return content;
  } catch (error) {
    console.error('Error in generateLessonContent:', error);
    throw error;
  }
}